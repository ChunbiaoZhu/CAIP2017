%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @InProceedings{10.1007/978-3-319-64698-5_2,
% author="Zhu, Chunbiao
% and Li, Ge
% and Guo, Xiaoqiang
% and Wang, Wenmin
% and Wang, Ronggang",
% title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
% booktitle="Computer Analysis of Images and Patterns",
% year="2017",
% publisher="Springer International Publishing",
% address="Cham",
% pages="14--23",
% abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
% isbn="978-3-319-64698-5"
% }
function [ Sal_weight ] = DES_2DContrastCue( ctrs ,idx)
%GETSALWEIGHT Summary of this function goes here
    con_ctrs = ctrs(:,1:3);
    pos_ctrs = ctrs(:,4:5)/max(max(ctrs(:,4:5)));
    bin_num=size(con_ctrs,1);
    bin_weight=zeros(bin_num,1);
    for i=1:bin_num
        bin_weight(i)=size(find(idx==i),1);
    end
    bin_weight=bin_weight/size(idx,1);
    Y = squareform(pdist(con_ctrs)).*repmat(bin_weight, [1, bin_num]).*exp(-squareform(pdist(pos_ctrs))/0.4);
    Sal_weight=sum(Y)';
end