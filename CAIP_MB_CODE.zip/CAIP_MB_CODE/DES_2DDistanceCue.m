%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @InProceedings{10.1007/978-3-319-64698-5_2,
% author="Zhu, Chunbiao
% and Li, Ge
% and Guo, Xiaoqiang
% and Wang, Wenmin
% and Wang, Ronggang",
% title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
% booktitle="Computer Analysis of Images and Patterns",
% year="2017",
% publisher="Springer International Publishing",
% address="Cham",
% pages="14--23",
% abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
% isbn="978-3-319-64698-5"
% }
function [ Dis_weight ] = DES_2DDistanceCue( idx, DisVector, para )
%GETPOSITIONW Summary of this function goes here
%   Detailed explanation goes here

Dis_weight=zeros(para.cluster_num,1);

for i=1:para.cluster_num
    x=sum(DisVector(idx==i))/size(DisVector(idx==i),1);
    Dis_weight(i) = exp(-x.^2/(para.img_W^2));
end

end

