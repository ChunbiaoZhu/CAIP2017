%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @InProceedings{10.1007/978-3-319-64698-5_2,
% author="Zhu, Chunbiao
% and Li, Ge
% and Guo, Xiaoqiang
% and Wang, Wenmin
% and Wang, Ronggang",
% title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
% booktitle="Computer Analysis of Images and Patterns",
% year="2017",
% publisher="Springer International Publishing",
% address="Cham",
% pages="14--23",
% abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
% isbn="978-3-319-64698-5"
% }
function [ Depsal_weight ] = DES_DepContrastCue( Depth_vector,idx,ctrs,para)
%GETSALWEIGHT Summary of this function goes here


    pos_ctrs = ctrs(:,4:5)/max(max(ctrs(:,4:5)));%mean coordinate
    poi = squareform(pdist(pos_ctrs));
    % ppoi = poi.^(-1);
    % ppoi(ppoi==Inf)=0;%self distance is 0
    bin_num = para.cluster_num;
    Depsal_weight = zeros(bin_num,1);
    bin_weight = zeros(bin_num,1);
    for i=1:bin_num% mean depth
        Depsal_weight(i) = sum(Depth_vector(idx==i))/size(find(idx==i),1);
    end    
    dismatrix = zeros(bin_num);
    for i=1:bin_num
        for j=1:bin_num
            dismatrix(j,i)=Depsal_weight(j)-Depsal_weight(i);
        end
    end

    for i=1:bin_num% number of pixels
        bin_weight(i)=size(find(idx==i),1);
    end
    bin_weight=bin_weight/size(idx,1);
    Y = dismatrix.*repmat(bin_weight, [1, bin_num]).*exp(-poi/para.sigma2);

    Depsal_weight=sum(Y)';
end
