%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @InProceedings{10.1007/978-3-319-64698-5_2,
% author="Zhu, Chunbiao
% and Li, Ge
% and Guo, Xiaoqiang
% and Wang, Wenmin
% and Wang, Ronggang",
% title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
% booktitle="Computer Analysis of Images and Patterns",
% year="2017",
% publisher="Springer International Publishing",
% address="Cham",
% pages="14--23",
% abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
% isbn="978-3-319-64698-5"
% }

close all;
clear all;
imgRoot='./Image/';
imnames=dir([imgRoot '*' 'jpg']);
centerRoot='./center_prior/center_results/';%% center-bias image dir
centernames=dir([centerRoot '*' 'png']);

for ii=1:length(imnames);
    disp(ii)
    imname=[imgRoot imnames(ii).name]; 
    RGB_img=imread(imname); 
    centername=[centerRoot centernames(ii).name]; 
    RGB_imgCenter=im2double(imread(centername)); 
    % image set path
    img_name = imname;
    % RGB_path= input_im;
    Depth_path= ['./Depth/' imnames(ii).name(1:end-4) '.jpg'];

    Result_path = FDS_mkdir('./OURS/');

    % parameters
    DES_para.cluster_num= 40; %clustering number 
    DES_para.sigma2 = 0.4;
    DES_para.gamma = 1;

    depth_map  = im2double(imread(Depth_path));


    [DES_para.img_H, DES_para.img_W, DES_para.img_C] = size(RGB_img); 
    DES_para.img_vector_size = DES_para.img_H* DES_para.img_W; 
    RGB_img = mat2gray(RGB_img);
    DES_Cue = DES_SaliencyCue( RGB_img, depth_map, DES_para );
    DES_Cue.FinalCue = DES_GaussNorm((DES_Cue.Contrast2D.*DES_Cue.Distance2D));

    % saliency map of stage 1  
    OURS1= ['./OURS1/' imnames(ii).name(1:end-4) '_ours1.png'];
    s1= im2double(imread(OURS1));
    
    % saliency map of stage 2  
    OURS2= ['./OURS2/' imnames(ii).name(1:end-4) '_ours2.png'];
    s2= im2double(imread(OURS2));
    
    % generate saliency map stage 3  
    Saliency_map = DES_GenerateMap(DES_para, DES_Cue);
    Final_saliency =10.*s2.*(s2+Saliency_map).*(Saliency_map+1-exp(-Saliency_map.*Saliency_map.*s1));
    
    imwrite(Final_saliency, [Result_path imnames(ii).name(1:end-4) '_ours.png'], 'png');
end