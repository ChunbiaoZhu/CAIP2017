CAIP2017 - 17th international Conference on Computer Analysis of Images and Patterns
 
A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining

Chunbiao Zhu1, Ge Li1*, Xiaoqiang Guo2, Ronggang Wang1, Wenmin Wang1

1School of Electronic and Computer Engineering, Shenzhen Graduate School, Peking University, Shenzhen, China 

2Academy of Broadcasting Science, SAPPRET Beijing, China




How to use:

1. Add test image to ./center_prior/Image/ and ./Image/ , then run center_prior to get the center image in ./center_prior/center_results/.
2. Add depth to ./Depth/, then run OURS1.m show the first layer result in ./OURS1/.
3. Run OURS2.m, then get the second layer result in ./OURS2/.
4. Run OURS.m, then get our final result in ./OURS/.

If you encounter an error, please restart MATLAB and re-run the code as described above.


If you use our codes,please cite this paper!

@InProceedings{10.1007/978-3-319-64698-5_2,
author="Zhu, Chunbiao
and Li, Ge
and Guo, Xiaoqiang
and Wang, Wenmin
and Wang, Ronggang",
title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
booktitle="Computer Analysis of Images and Patterns",
year="2017",
publisher="Springer International Publishing",
address="Cham",
pages="14--23",
abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
isbn="978-3-319-64698-5"
}



If you have any question,please email us!

Email: zhuchunbiao@pku.edu.cn,*geli@ece.pku.edu.cn

Thank you! 