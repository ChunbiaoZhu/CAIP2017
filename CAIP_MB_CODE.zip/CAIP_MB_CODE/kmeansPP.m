
function [L,C] = kmeansPP(X,k)
%KMEANS Cluster multivariate data using the k-means++ algorithm.
%   [L,C] = kmeans(X,k) produces a 1-by-size(X,2) vector L with one class
%   label per column in X and a size(X,1)-by-k matrix C containing the
%   centers corresponding to each class.

%copyright@zhuchunbiao@pku.edu.cn
%cite as:
% @InProceedings{10.1007/978-3-319-64698-5_2,
% author="Zhu, Chunbiao
% and Li, Ge
% and Guo, Xiaoqiang
% and Wang, Wenmin
% and Wang, Ronggang",
% title="A Multilayer Backpropagation Saliency Detection Algorithm Based on Depth Mining",
% booktitle="Computer Analysis of Images and Patterns",
% year="2017",
% publisher="Springer International Publishing",
% address="Cham",
% pages="14--23",
% abstract="Saliency detection is an active topic in multimedia field. Several algorithms have been proposed in this field. Most previous works on saliency detection focus on 2D images. However, for some complex situations which contain multiple objects or complex background, they are not robust and their performances are not satisfied. Recently, 3D visual information supplies a powerful cue for saliency detection. In this paper, we propose a multilayer backpropagation saliency detection algorithm based on depth mining by which we exploit depth cue from four different layers of images. The evaluation of the proposed algorithm on two challenging datasets shows that our algorithm outperforms state-of-the-art.",
% isbn="978-3-319-64698-5"
% }

L = [];
L1 = 0;

while length(unique(L)) ~= k
    
    C = X(:,1+round(rand*(size(X,2)-1)));
    L = ones(1,size(X,2));
    for i = 2:k
        D = X-C(:,L);
        D = cumsum(sqrt(dot(D,D)));
        if D(end) == 0, C(:,i:k) = X(:,ones(1,k-i+1)); return; end
        C(:,i) = X(:,find(rand < D/D(end),1));
        [tmp,L] = max(bsxfun(@minus,2*real(C'*X),dot(C,C).'));
    end
    
    while any(L ~= L1)
        L1 = L;
        for i = 1:k, l = L==i; C(:,i) = sum(X(:,l),2)/sum(l); end
        [tmp,L] = max(bsxfun(@minus,2*real(C'*X),dot(C,C).'),[],1);
    end
    
end
